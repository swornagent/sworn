---
title: AGENTS.md fragment — canonical block to copy
description: The minimal text block to paste into your project's AGENTS.md (or CLAUDE.md, GEMINI.md, etc.) to adopt Baton
---

# AGENTS-fragment.md

Copy the block below into your project's agent-instructions file. Trim or extend project-specific examples; the core rules are minimal by design.

---

## Engineering Process — Baton

This project follows the **Baton** rule-set (see `/docs/baton/` for full rule docs and provenance). Twelve rules, listed in priority order:

### 1. Reachability Gate (CRITICAL)

For any feature with a user-facing affordance (UI control, route, form field, API endpoint), the first failing test must render through the integration point that owns the affordance — NOT the leaf component in isolation.

- If the integration point can't render the feature yet, THAT failure is the correct TDD red. Build the integration glue first; the leaf falls out.
- Leaf-level unit tests are fine in addition. They cannot be the sole proof of life.
- A component imported only by its own test file is a red flag. Investigate before claiming task done.
- "Pass 1 / Pass 2" splits are acceptable ONLY when Pass 2 is created, tracked, and owned at the moment Pass 1 lands.

Before marking any phase complete, produce a **reachability artefact**: screenshot, end-to-end test run, or explicit "open browser, do X, observe Y" smoke step. A green typecheck plus green unit suite is not a reachability artefact.

### 2. No Silent Deferrals

"Deferred" as an inline code comment is not a decision unless all three are present:

1. **Why** — concrete reason (framework limitation, blocking dependency, scope cut)
2. **Tracking** — linked issue, plan task, or punch-list item
3. **Acknowledgement** — decision-maker told in plain text

Without all three, the inline comment is rationalisation, not decision. When tempted to write `// deferred` / `// later` / `// future` / `// TODO` on a schema or contract surface, surface the decision first.

### 3. Capture Discipline

Conversation context is the most ephemeral persistence layer. Subagent findings + session decisions must land in durable storage before session ends.

**Durability hierarchy (most to least permanent):**

1. Git history (commit messages)
2. Code itself
3. `/docs/` content
4. GitHub Issues + comments
5. Per-project memory
6. Conversation context

Bias every capture decision toward higher-numbered-permanence layers. Conversation context is a working surface, not a storage surface.

**Subagent output handling:** any subagent dispatch producing a substantial findings doc MUST save its output to `docs/captures/<date>-<topic>.md` as part of the agent's task, not just return to conversation.

### 4. Commit Messages as Capture Layer

Commits that land a documented decision MUST restate the decision in the message body, not just "see plan X."

- Plans get edited and moved; `git log --format="%B"` is permanent.
- Use 3-5 line bodies for any commit landing a decision, even when the diff is small.
- Trailers (Co-Authored-By, etc.) come after rationale, not in place of it.
- Single-line commit messages are fine for trivial mechanical changes.

### 5. Session Discipline

Implementation sessions of non-trivial scope are anchored to GitHub Issues.

- **Session start:** Ask which issue the work belongs to. If none, create one before starting.
- **During the session:** At natural breakpoints, capture key decisions, trade-offs, and progress to the issue.
- **Session end:** Record decisions, completed work, deferred items, next steps. If substantial analysis happened, write a handoff capture at `docs/captures/<date>-<topic>-handoff.md`.

Use GitHub Issues for epics, feature specs, implementation plans, session captures. Use `/docs/` for ADRs, RFCs, operational guides, strategy docs, stable reference material. If the content will become stale as work progresses, it belongs in an issue rather than `/docs/`.

### 6. Proof Bundle (CRITICAL)

Before marking any task, phase, or session complete, the agent must produce a **proof bundle** at `docs/captures/<date>-<topic>-proof.md` (prose; or, for release-mode work, the `proof.json` record at `docs/release/<release-name>/<slice-id>/proof.json`, rendered to Markdown for review). The bundle must be generated from live repo state — not recalled from context.

**Required sections:**
- **Scope** — one sentence: what was this task meant to deliver?
- **Files changed** — output of `git diff --name-only <base-branch>`
- **Test results** — output of `<your backend test command>` and `<your frontend test command>`
- **Reachability artefact** — path or explicit smoke-step description (see Rule 1)
- **Delivered** — bulleted list with evidence reference (file, test name, artefact path) for each item
- **Not delivered** — bulleted list; each item surfaced as a Rule 2 deferral with why + tracking + acknowledgement
- **Divergence from plan** — any implementation that differs from the plan; empty is valid but the section must be present

**Claiming completion without a proof bundle is a silent deferral of verification and is subject to Rule 2.**

**Continuation handshake:** every session resuming prior work must open by regenerating the "Files changed" and "Test results" sections from live repo state and reconciling against the prior bundle's "Delivered" list before any new implementation begins. Divergences must be surfaced before proceeding.

**Scope ceilings:** subagent dispatches must be bounded to one vertical slice (one user-reachable journey, one API endpoint, one UI section, one migration). Dispatches scoped as "finish the feature" produce reports too broad to verify. Decompose first; each slice gets its own bundle.

### 7. Adversarial Verification (CRITICAL)

No slice may transition to `verified` state without a PASS verdict from a **fresh-context session** loaded only with the slice artefacts (`spec.json`, `proof.json`, `status.json`) and live repo state. The session that implemented the slice is never allowed to certify the slice.

**Separation is about context, not model identity.** Same model, fresh window, artefact-only inputs is sufficient. The verifier must not load the implementer's session transcript, wrap-up message, or any "ready for review" prose.

**Verifier return contract:** exactly one of
- `PASS` — every gate satisfied; slice can move to `verified`
- `FAIL: <numbered concrete violations>` — each tied to a specific spec acceptance check or proof-bundle gate
- `BLOCKED: <reason>` — verification cannot proceed (missing artefact, unrunnable test command, etc.)

**Fail closed.** Absence of evidence is FAIL, not optimistic PASS. The verifier does not propose redesigns, does not edit production code, and does not consult the implementer for clarification.

**Slice state machine:** `planned → in_progress → implemented → [fresh verifier] → verified | failed_verification`. The `implemented` checkpoint exists specifically so no agent can shortcut directly to `verified`. A Track Integrator has one fail-closed exception: a recognized synchronization merge that contributes an intersecting path after its latest reviewed frontier may invalidate `verified → failed_verification` only when that slice's complete candidate set is disjoint from every later authoritative slice, preserving the ledger and exact parent-2 baseline for rollback-backed re-slicing. It never creates `verified`, appends a Verifier report, rewrites `shipped`, or fabricates rollback metadata for unowned/custom/overlapping-later history.

**Cheap-cost loop:** implementer writes the proof bundle, runs the proof-bundle verification gate (`sworn verify`) for deterministic first-pass rejection, then a fresh session with `role-prompts/verifier.md` returns the verdict. One extra session per slice. On Max-plan tooling this is effectively free; on API usage it is still cheaper than the rework cost of an overclaimed slice.

### 8. Requirements Fidelity (CRITICAL)

The spec is not an axiom. Rules 1/6/7 verify delivery against the spec but treat the spec itself as correct; the front half of the chain — from intake need to acceptance criterion — goes unverified. Before a slice enters implementation its requirements must be **verified** (each acceptance criterion is singular, unambiguous, complete, consistent, feasible, and verifiable — the ISO/IEC/IEEE 29148 quality characteristics), **validated** (a human-owned positive-and-negative scenario sense-check confirms the spec serves the need), and **traced** (every need links to an acceptance criterion, every criterion back to a need and forward to a test, and every slice up a vertical golden thread to its release goal). A 2-D requirements traceability matrix, built fail-closed from `intake.md` / `spec.json` / `status.json` / `board.json`, makes a dropped need a hard, detectable trace break. Acceptance criteria use EARS notation; a Definition of Ready gate composes traced + verified + validated into one fail-closed verdict before `planned → in_progress`.

### 9. Design Fidelity (CRITICAL)

Meeting a requirement is not the same as the right solution for the whole — solution fit is a quality the delivery verifier (Rule 7) cannot see in the diff. Design stays **human-owned** and AI-augmented, with the amount of human judgement calibrated to each choice's stakes (reversibility × blast-radius). Type-1 choices (hard to reverse, wide/structural — and all architecturally-significant choices) require a full human decision with options + rationale recorded in `status.json`; Type-2 choices (easy to reverse, narrow/local) may proceed with a noted default. The model may propose options and classify stakes but may not record a Type-1 human decision itself. A deterministic gate fails closed on any Type-1 choice missing a human decision or any architecturally-significant choice not classified Type-1. UI-bearing projects must declare a design system (tokens + component library); a two-layer conformance audit catches hardcoded colours, off-scale spacing, and recreated components (machine-check), then requires a human on-brand cohesion verdict. In an autonomous loop with no human present, the gate is keyed to the stakes class: a Type-2 choice may auto-proceed with its default recorded; a Type-1/architecturally-significant choice by default hard-pauses for asynchronous Coach acknowledgement (never auto-proceed; a captain self-review may enrich the pins but not clear the gate). The default is overridable — an operator may grant auto-proceed authority on Type-1 via an explicit, recorded governance setting (`autonomous_design_authority`), scaled to codebase maturity, model capability, and risk tolerance. This is delegation, not abdication: the human still decides *whether*, once, ahead of time; the auto-proceeded decision is fully recorded and attributed to that standing delegation. Autonomy changes when the human decides, never whether.

### 10. Customer Journey Validation (CRITICAL)

Critical customer journeys are a first-class artefact, not a per-release afterthought. A journey is an ordered, end-to-end path a user type takes across many slices to achieve an outcome — the unit of cross-slice evidence that per-slice verification (Rule 7) structurally cannot give. Before a release ships its journeys must be **elicited** (model-drafted), **ratified** (human-reviewed and edited), and **durable** (persisted to a version-controlled artefact maintained release over release). A fail-closed gate runs after all slices verify but before merge: exit 0 only when the artefact exists and is human-ratified. The **no-mock boundary** is the rule's enforcement teeth: a journey walked over a mocked boundary (DB, auth, entitlement) proves nothing, so an undeclared mock at a validated boundary fails the gate closed — a mock there is permitted only as a declared Rule 2 deferral. The same principle applies earlier at slice level (**mock parity**): a consumer slice may mock a boundary registered in the release's contract registry (`contracts.json`, `contracts-v1`) only with fixtures recorded by the owner's live contract test — a hand-written mock at a registered boundary is a silent deferral unless the consumer includes at least one unmocked round-trip against the real handler. A "mock at a boundary" is a **code construct** (a call/binding substituting the boundary), detected against code tokens, not the textual appearance of `mock`/`@no-mock` inside string literals or comments — so code that legitimately parses the annotation vocabulary is not failed closed. Between track merge and ship sits the **assembly stage** (`tracks-merged → assembled → journey-validated → merged`): the release is `assembled` when a passing `assembly-proof.json` exists on `release-wt/<name>` — emitted by an end-to-end, no-mock assembly run over the merged release (reference implementation: `sworn assemble`) — and `/merge-release` gates on it. At release cutover the touched journeys are re-walked against real infra, after the assembly run passes, guided by a generated **cutover QA runbook** (`qa-runbook.md`, rendered from the release's records — reachability smoke-steps, touched journeys, delivered lists, new wire surfaces — to *target* manual QA, not replace it), and human-attested.

### 11. Process-Global Mutation Guard (CRITICAL)

Any change — test or production — that mutates **process-global state** (the working directory, environment variables, or which worktree/branch a tool operates on) must satisfy three things before the owning slice can reach `verified`: **guaranteed restore** (prefer scoped mutation — an explicit working-directory argument or a framework helper that auto-restores — over mutating the ambient process), a **fail-closed target assertion** (any operation acting on a path/worktree, especially a `git` op carrying a directory argument, must first assert the target exists and is the expected directory), and a **reachability artefact** proving the guard fires. Load-bearing wherever sessions run concurrently against a shared base: an unrestored mutation is silently inherited by the next unit of work, and a git op in an unexpected directory can corrupt branch state. The same principle governs **resume after an unclean exit**: a resumed loop must restore each track worktree to its committed slice state (`reset --hard` + `clean`, target asserted first) before re-dispatching, so crash debris cannot contaminate the retry's diff or the gates that scan it — recovering *cleanly*, not merely without corrupting.

### 12. Guard Fidelity (CRITICAL)

A **guard** — any automated check that prevents a class of defect recurring (regression test, lint rule, CI gate, invariant) — may be cited as proof-bundle evidence (Rule 6) or relied on by a verifier (Rule 7) only if it satisfies four conditions: **(1) mutation proof** — break the thing it protects, see red, restore, see green, record both (a guard that has never failed is a decoration that returns green); **(2) scope parity** — the domain the guard checks equals the domain the claim quantifies over (a check narrower than its claim is worse than no check, because it converts an unknown into a false assurance); **(3) mutate the form the defect ACTUALLY takes**, not the form you imagined — the condition nearly always violated, because a guard that catches only the shape you thought of passes its own mutation test and still misses every real instance; **(4) right instrument** — a parser, not a regex, when detection needs scope, bindings, or structure. **Corollary — quantifier discipline:** "no X exists" / "every Y is Z" / "machine-checked" is a promise about a search you have not run; state it only if a check covers the whole domain, else bound the claim to the search you actually ran. A guard fails loudly (red on correct code, self-correcting) or **silently** (green over a domain it never searched) — the silent one adds confidence while removing safety and is invisible at every layer above it. Numbered last but logically upstream of 6/7: it governs whether their evidence means anything.

---

Full rule docs with provenance and detailed examples: `/docs/baton/`. Release Mode harness — slice template, role prompts, record schemas: `/docs/baton/release-mode-template/`, `/docs/baton/role-prompts/`, schemas at `https://baton.sawy3r.net/schemas/`. Baton ships no binaries; the mechanical gates (trace, coverage, design-conformance, mock-boundary, regression, proof-bundle verification, and the board oracle) and the deterministic LLM checks (prompt bodies specified in `/docs/baton/llm-checks/`) are run by a conformant engine — reference implementation: the open `sworn` binary, which Release Mode requires. Architecture rules: `docs/baton/architecture.json`.
